import sys 




if __name__ == '__main__':
	print("\x00" * 10 + "A+")
